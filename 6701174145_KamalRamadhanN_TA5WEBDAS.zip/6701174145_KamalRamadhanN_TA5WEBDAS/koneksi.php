<?php 
$conn = mysqli_connect("localhost","root","","d_modul5");
 ?>