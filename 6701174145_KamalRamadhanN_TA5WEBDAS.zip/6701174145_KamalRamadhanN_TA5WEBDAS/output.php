<?php 

session_start();
include 'koneksi.php';
$nim = $_SESSION['id'];
$query = mysqli_query($conn,"SELECT * FROM t_jurnal1 WHERE  NIM = '$nim'");
if ($arr=mysqli_fetch_array($query)) {
	$namaa=$arr['Nama'];
	$nm=$arr['NIM'];	
	$em=$arr['email'];	
	$tgl=$arr['tgl_lahir'];	
	$jenkel=$arr['jk'];	
	$jurs=$arr['jurusan'];	
	$fakl=$arr['fakultas'];		

}else{echo "GAGAL";}
?>
<form method="post">
<table>
	<tr>
		<td>Nama :</td>
		<td><?php echo $namaa."<br>"; ?></td>
	</tr>
	<tr>
		<td>NIM :</td>
		<td><?php echo $nm."<br>"; ?></td>
	</tr>
	<tr>
		<td>Tanggal lahir :</td>
		<td><?php echo $tgl."<br>"; ?></td>
	</tr>
	<tr>
		<td>Email :</td>
		<td><?php echo $em."<br>"; ?></td>
	</tr>
	<tr>
		<td>Jenis kelamin :</td>
		<td><?php echo $jenkel."<br>"; ?></td>
	</tr>
	<tr>
		<td>Jurusan :</td>
		<td><?php echo $jurs."<br>"; ?></td>
	</tr>
	<tr>
		<td>fakultas :</td>
		<td><?php echo $fakl."<br>"; ?></td>
	</tr>

	<tr>
		<td><input type="submit" name="keluar" value="Input Lagi"></td>
	</tr>
</table>
	
</form>
<?php 
if (isset($_POST['keluar'])) {
	session_destroy();
	header("Location:input.php");
}
 ?>