<form method="POST">
	<table>
		<tr>
			<td>Nama</td>
			<td><input type="text" name="nama"></td>
		</tr>
	
		<tr>
			<td>NIM</td>
			<td><input type="text" name="nim"></td>
		</tr>

		<tr>
			<td>Email</td>
			<td><input type="text" name="email" placeholder="example@gmail.com"></td>
		</tr>
		
		<tr>
			<td>Tanggal Lahir</td>
			<td><input type="date" name="date"></td>
		</tr>
		
		<tr>
			<td>Jenis Kelamin</td>
			<td><input type="radio" name="jk" value="Laki-Laki">laki-laki <br>
				<input type="radio" name="jk" value="Perempuan">Perempuan</td>
		</tr>
		
		<tr>
			<td>Program Studi</td>
			<td><select name="ps">
				<option>---PILIH---</option>
				<option value="Manajemen informatika">Manajemen informatika</option>
				<option value="Administrasi Bisnis">Admnistrasi Bisnis</option>
				<option value="Teknik komputer">Teknik komputer</option>
				<option value="Ilmu Komunikasi">Ilmu Komunikasi</option>
			</select></td>
		</tr>
		
		<tr>
			<td>Fakultas</td>
			<td><select name="f">
				<option>---PILIH---</option>
				<option value="Fakultas Ilmu Terapan">Fakultas Ilmu Terapan</option>
				<option value="Fakultas Komunikasi Bisnis">Fakultas Komunikasi Bisnis</option>
				<option value="Fakultas Teknik Elektro">Fakultas Teknik Elektro</option>
				<option value="Fakultas Ekonomi Bisnis">Fakultas Ekonomi Bisnis</option>
			</select></td>
		</tr>
		
		<tr>
			<td><input type="submit" name="send" value="submit"></td>
		</tr>
	</table>
</form>

<?php 
include 'koneksi.php';

if (isset($_POST['send'])) {
	
	if (strlen($_POST['nim'])==10 && $_POST['nim']!="" && is_numeric($_POST['nim'])) {
	$nimm = $_POST['nim'];	
	}else{
		echo "NIM kurang"."<br>";
	}

	if (strlen($_POST['nama'])>20 || $_POST['nama']=="") {
		echo "Nama anda tidak valid"."<br>";
	}else{
		$name = $_POST['nama'];
	}

	if (!strpos($_POST['email'], "@")||!strpos($_POST['email'], ".com")) {
		echo "Email anda tidak sesuai"."<br>";
	}else{
		$e = $_POST['email'];
	}

	$tanggal = $_POST['date'];
	$dr = $_POST['ps'];
	$dr1 = $_POST['f'];
	if (isset($_POST['jk'])) {
		$rd = $_POST['jk'];	
	}
	
	

	if (isset($nimm) && isset($name) && isset($e)&& isset($tanggal)&& isset($dr)&& isset($dr1)&& isset($rd)) {
		session_start();
		$_SESSION['id'] = $nimm;		
		$query = mysqli_query($conn,"INSERT INTO t_jurnal1(NIM, Nama, email, tgl_lahir, jk, jurusan, fakultas) VALUES ('$nimm','$name','$e','$tanggal','$rd','$dr','$dr1')");
		$querry = mysqli_query($conn,"SELECT * FROM t_jurnal1 ");
		$arr=mysqli_fetch_array($querry);
	if (isset($query)) {
		echo "DATA TERSIMPAN";
		header("Location:output.php");
		}else{
			echo "DATA TIDAK TERSIMPAN";
		}
	}
	
}



	
 

 ?>